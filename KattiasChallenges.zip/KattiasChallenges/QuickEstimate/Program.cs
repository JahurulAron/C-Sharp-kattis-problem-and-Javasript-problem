﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuickEstimate
{
    class Program
    {
        //Q-https://open.kattis.com/problems/quickestimate
        static void Main(string[] args)
        {
            int testcases = int.Parse(Console.ReadLine());
            while (testcases >0)
            {
                Console.WriteLine();
                Console.Write(Console.ReadLine().Length);
              
                testcases--;
                Console.ReadKey();
            }
            Console.ReadKey();
        }
    }
}
