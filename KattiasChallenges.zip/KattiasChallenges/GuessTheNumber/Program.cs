﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GuessTheNumber
{
    class Program
    {
        static void Main(string[] args)
        {
            int lower = 1;
            int upper = 1000;
            int answer = 500;
            // Console.WriteLine(answer);

            Console.WriteLine("Please write your guess number" );
          
                int result = int.Parse(Console.ReadLine());

                if (result== answer)
                {
                    Console.WriteLine("Correct");
                  
                }
               else if (result < answer)
                {
                    upper = answer;
                    answer = (lower + upper) / 2;
                    Console.WriteLine("Lower");

                }
               else if (result > answer)
                {
                    lower = answer;
                    answer = (lower + upper + 1) / 2;
                    Console.WriteLine("Higher");

                }


            Console.ReadKey();
            
        }
    }
}
