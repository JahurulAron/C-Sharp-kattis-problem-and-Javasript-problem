﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Eiligibility
{
    class Program
    {
        static void Main(string[] args)
        {
            int numCases = int.Parse(Console.ReadLine());

            while (numCases > 0)
            {
                string[] information = Console.ReadLine().Split(' ');
                string name = information[0];
                int startYear = int.Parse(information[1].Substring(0, 4));//2013
                int birthYear = int.Parse(information[2].Substring(0, 4));//1995
                int courses = int.Parse(information[3]);

                Console.Write(name + " ");

                if (startYear >= 2010 || birthYear >= 1991)
                {
                    Console.Write("eligible");
                }
                else if (courses < 41)
                {
                    Console.Write("coach petitions");
                }
                else
                {

                    Console.Write("ineligible");

                }
                numCases--;
                    }
                Console.ReadKey(); ;
            }

        }
    }

