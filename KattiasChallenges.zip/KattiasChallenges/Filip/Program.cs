﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Filip
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] numbers = Console.ReadLine().Split();
          
            int a = int.Parse(numbers[0]);
            int b = int.Parse(numbers[1]);
            int numberone = 0;
            while (a> 0)
            {
                int remainder = a % 10;
                numberone = (numberone * 10) + remainder;
                a = a/ 10;
            }
           Console.WriteLine("Reverse No. is {0}", numberone);

            int numbertwo = 0;
            while (b > 0)
            {
                int remainder = b % 10;
                numbertwo = (numbertwo * 10) + remainder;
                b= b / 10;
            }
           Console.WriteLine("Reverse No. is {0}", numbertwo);
            //Displaying the reverse word  


             Console.WriteLine(Math.Max(numberone, numbertwo));
            Console.ReadKey();
        }
    }
}
