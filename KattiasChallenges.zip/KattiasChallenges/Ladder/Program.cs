﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ladder
{
    class Program
    {
        static void Main(string[] args)
        {
            //q-https://open.kattis.com/problems/ladder
            string[] values = Console.ReadLine().Split(' ');
            int height = int.Parse(values[0]);
            double degrees = Math.PI/180*(int.Parse(values[1]));
            int hypotenuse = (int)Math.Ceiling(height / Math.Sin(degrees));

            Console.WriteLine(hypotenuse);
            Console.ReadKey();
        }
    }
}
