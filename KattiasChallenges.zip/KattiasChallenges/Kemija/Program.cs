﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kemija
{
    class Program
    {
        static void Main(string[] args)
        {

            //Q:-https://open.kattis.com/problems/kemija08

            //string[] sentences = Console.ReadLine().Split(' ');
            List<char> vowels = new List<char> ();

            char[] vowel = { 'a', 'e', 'i', 'o', 'u', 'y' };
            // "a", "e", "i", "o", "u", "y"
            //'a', 'e', 'i', 'o', 'u', 'y'
            for (int i = 0; i <vowel.Length; i++)
            {
                vowels.Add((char)i);
            }





            Console.WriteLine(" "); 
                Console.ReadKey();
            }
    }
}
