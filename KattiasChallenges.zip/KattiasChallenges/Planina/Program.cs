﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Planina
{
    class Program
    {
        static void Main(string[] args)
        {
            //Q-https://open.kattis.com/problems/planina
            int numofiteration = int.Parse(Console.ReadLine());
            int numofpoint = (int)Math.Pow(2,numofiteration)+1;
            int result = numofpoint * numofpoint;
            Console.WriteLine(result);
            Console.ReadKey();
        }
    }
}
