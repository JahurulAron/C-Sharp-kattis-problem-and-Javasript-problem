﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PhoneList
{
    class Program
    {
        static void Main(string[] args)
        {
            //Q-https://open.kattis.com/problems/phonelist

            int numCases = int.Parse(Console.ReadLine());

            while (numCases-- > 0)
            {
                int num = int.Parse(Console.ReadLine());

                string[] phoneNumbers = new string[num];
             
                for (int i = 0; i < num; i++)
                {
                    phoneNumbers[i] = Console.ReadLine();
                }
                Array.Sort(phoneNumbers);
                //Console.WriteLine(phoneNumbers[0]);
                //Console.WriteLine(phoneNumbers[phoneNumbers.Length-1]);

                bool consistent = true;

                for (int i = 0; i < num - 1; i++)
                {
                    if (phoneNumbers[i + 1].StartsWith(phoneNumbers[i]))
                    {
                        consistent = false;
                        break;
                    }
                }

                if (consistent)
                {
                    Console.WriteLine("YES");
                }
                else
                {
                    Console.WriteLine("NO");
                }

              
                Console.ReadKey();
            }
        }
    }
}
