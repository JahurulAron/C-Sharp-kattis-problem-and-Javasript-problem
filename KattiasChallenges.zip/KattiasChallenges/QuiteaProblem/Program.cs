﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuiteaProblem
{
    class Program
    {
        static void Main(string[] args)
        {
            //Q-https://open.kattis.com/problems/quiteaproblem
            string line = Console.ReadLine();
            while (line!=null)
            {
                Console.WriteLine(line.ToLower().Contains("problem")?" yes":" no");
                line = Console.ReadLine();
                Console.ReadKey();
            }
        }
    }
}
