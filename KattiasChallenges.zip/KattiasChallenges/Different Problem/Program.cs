﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Different_Problem
{
    class Program
    {
        static void Main(string[] args)
        {
            string input;
            while ((input = Console.ReadLine()) != null)
            {
                string[] numbers = input.Split(' ');
                Console.WriteLine(Math.Abs(long.Parse(numbers[0]) - long.Parse(numbers[1])));
            }
        }

    }
}
