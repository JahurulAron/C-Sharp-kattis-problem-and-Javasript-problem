﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Factor
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] data = Console.ReadLine().Split(' ');
            int publicearticles = int.Parse(data[0]);
            int onwerrequre = int.Parse(data[1]);
            int output = publicearticles * (onwerrequre - 1) + 1;
            Console.WriteLine(output);
            Console.ReadKey();

        }
    }
}
