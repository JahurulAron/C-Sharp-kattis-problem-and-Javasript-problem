﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MixedFractions
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {


                string[] data = Console.ReadLine().Split(' ');
                int numerator = int.Parse(data[0]);
                int denomerator = int.Parse(data[1]);

                if (numerator == 0 && denomerator == 0)
                {
                    break;

                }
                int total = numerator / denomerator;
                int remainder = numerator % denomerator;
                Console.WriteLine(total + " " + remainder + " / " + denomerator);

                Console.ReadKey();
            }

        }
    }
}
