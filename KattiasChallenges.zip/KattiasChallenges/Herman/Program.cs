﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Herman
{
    class Program
    {
        static void Main(string[] args)
        {
            int radius = int.Parse(Console.ReadLine());

            double euclidean = Math.PI * Math.Pow(radius, 2);
            double taxicab = 2 * Math.Pow(radius, 2);

            Console.WriteLine(euclidean + "\n" + taxicab);
            Console.ReadKey();
        }
    }
}
