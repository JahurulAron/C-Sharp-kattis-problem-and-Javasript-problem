﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EstimatingTheAreaOfACircle
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                string[] data = Console.ReadLine().Split(' ');

                double radius = double.Parse(data[0]);
                double pointsTotal = int.Parse(data[1]);
                double pointsInside = int.Parse(data[2]);

                if (radius == 0 && pointsTotal == 0 && pointsInside == 0)
                {
                    break;
                }

                double radius2 = radius * radius;
                double realR = Math.PI * radius2;
                double estimateR = 4 * radius2 * (pointsInside / pointsTotal);
                // Formula of the square area in terms of the inradius A = 4r2


                Console.WriteLine(realR + " " + estimateR); 
            }
            Console.ReadKey();
        }
    }
}
