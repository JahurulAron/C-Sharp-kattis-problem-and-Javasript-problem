﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Easiest
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                int number = int.Parse(Console.ReadLine());
                if (number == 0)
                {
                    break;
                }

                int target = sumOfDigits(number);
                int minimal = 11;

                while (true)
                {
                    if (sumOfDigits(number * minimal) == target)
                    {
                        Console.WriteLine(minimal);
                        break;
                    }
                    minimal++;
                }
            }
            Console.ReadKey();
        }

            public static int sumOfDigits(int number)
            {
                int sum = 0;

                char[] numbArr = number.ToString().ToCharArray();
                foreach (char c in numbArr)
                {
                    sum += numbArr[c];
                }


                return sum;
            }

        }
    }
    

