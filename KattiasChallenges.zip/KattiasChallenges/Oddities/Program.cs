﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oddities
{
    class Program
    {
        static void Main(string[] args)
        {
            //q-https://open.kattis.com/problems/oddities
            int numcases = int.Parse(Console.ReadLine());
            while (numcases -->0)
            {
                int number = int.Parse(Console.ReadLine());
                if (number%2==0)
                {
                    Console.WriteLine($"{number} is even");
                }
                else
                {
                    Console.WriteLine($"{number} is odd");
                }
                
            }

            Console.ReadKey();
        }
    }
}
