﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Parking2
{
    class Program
    {
        static void Main(string[] args)
        {
            //Q-https://open.kattis.com/problems/parking2
            int numCases = int.Parse(Console.ReadLine());

            while (numCases-- > 0)
            {
                int numStores = int.Parse(Console.ReadLine());

                string[] data = Console.ReadLine().Split(' ');
                List<int> numbers = new List<int>();
                for (int i = 0; i < numStores; i++)
                {
                    numbers.Add(int.Parse(data[i]));
                }
                var minnum = numbers.Min();
                var maxnum = numbers.Max();
                var result = 2 * (maxnum - minnum);
                Console.WriteLine(result);
                Console.ReadKey();
            }
            //while (numCases-- > 0)
            //{
            //    int numStores = int.Parse(Console.ReadLine());
            //    string[] data = Console.ReadLine().Split(' ');

            //    int min = int.MaxValue;
            //    int max = int.MinValue;
            //    for (int i = 0; i < numStores; i++)
            //    {
            //        int position = int.Parse(data[i]);
            //        if (position < min)
            //        {
            //            min = position;
            //        }
            //        if (position > max)
            //        {
            //            max = position;
            //        }
            //    }

            //    Console.WriteLine((max - min) * 2);
            //    Console.ReadKey();
        }
        }
    }
