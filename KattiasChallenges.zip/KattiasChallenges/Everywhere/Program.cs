﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Everywhere
{
    class Program
    {
        static void Main(string[] args)
        {
            int numCases = int.Parse(Console.ReadLine());

            while (numCases-- > 0)
            {
                List<string> locations = new List<string>();
               
                int numTrips = int.Parse(Console.ReadLine());

                for (int i = 0; i < numTrips; i++)
                {
                    locations.Add(Console.ReadLine());
                }
                Console.WriteLine( locations.Distinct().Count()); 
            }
            Console.ReadKey();
        }
    }
}
