﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nastyhacks
{
    class Program
    {
        static void Main(string[] args)
        {
            //q-https://open.kattis.com/problems/nastyhacks
            int numcases = int.Parse(Console.ReadLine());
            while (numcases -->0)
            {


                string[] money = Console.ReadLine().Split(' ');
                int noadvert = int.Parse(money[0]);
                int advert = int.Parse(money[1]);
                int cost = int.Parse(money[2]);
                if ((advert-cost)>noadvert)
                {
                    Console.WriteLine("advertise");
                }

                else if ((advert-cost)<noadvert)
                {
                    Console.WriteLine("do not advertise");

                }
                else  /*((advert-cost)==noadvert)*/
                {
                    Console.WriteLine("does not matter");
                }
               
                Console.ReadKey();
            }

        }
    }
}
