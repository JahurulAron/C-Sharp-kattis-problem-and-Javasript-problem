﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FizzBuzz
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] numbers = Console.ReadLine().Split(' ');
            int x = int.Parse(numbers[0]);
            int y = int.Parse(numbers[1]);
            int n = int.Parse(numbers[2]);

            for (int i = 1; i <= n; i++)
            {
                bool triggered = false;

                if (i % x == 0)
                {
                    triggered = true;
                    Console.WriteLine("Fizz");

                }
                if (i % y == 0)
                {
                    triggered = true;
                    Console.WriteLine("Buzz");
                }

                if (triggered)
                {
                    Console.WriteLine(" ");
                }
                else
                {
                    Console.WriteLine(i);
                }

            }

            Console.ReadKey();
        }

    }

}