﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuickBrownFox
{
    class Program
    {
        static void Main(string[] args)
        {
            //Q-https://open.kattis.com/problems/quickbrownfox
            int numCases = int.Parse(Console.ReadLine());

            while (numCases-- > 0)
            {
                List<char> letters = new List<char>();

                char[] text = Console.ReadLine().ToLower().ToCharArray();

                foreach (var c in text)
                {
                    if (c >= 'a' && c <= 'z')
                    {
                        letters.Add(c);
                    }
                }


                int start = 'a';
                int end = 'z';
                string missing = "";

                for (int i = start; i <= end; i++)
                {
                    char c = (char)i;
                    if (!letters.Contains(c))
                    {
                        missing += c;
                    }
                }
                Console.WriteLine(missing);
                if (missing.Equals(""))
                {
                    Console.WriteLine("pangram");
                }
                else
                {
                    Console.WriteLine("missing " + missing);
                }

            }
            Console.ReadKey();
        }
       

    }
}
