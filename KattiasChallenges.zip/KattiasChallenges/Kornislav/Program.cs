﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kornislav
{
    class Program
    {
        static void Main(string[] args)
        {
            //q.-https://open.kattis.com/problems/kornislav
            string[] distances = Console.ReadLine().Split(' ');
           // int[] steps = new int[distances.Length];
            List <int > steps= new List<int>();
            for (int i = 0; i < distances.Length; i++)
            {
                steps.Add( int.Parse(distances[i]));
            }
            steps.Sort();
            
            Console.WriteLine(steps[0] * steps[2]);
            Console.ReadKey();
        }
    }
}
