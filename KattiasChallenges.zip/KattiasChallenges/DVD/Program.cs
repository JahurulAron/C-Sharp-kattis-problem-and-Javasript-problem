﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DVD
{
    class Program
    {
        static void Main(string[] args)
        {
            int numCases = int.Parse(Console.ReadLine());

            while (numCases> 0)
            {
                Console.ReadLine();

                string[] dvds = Console.ReadLine().Split(' ');


                int operations = 0;
                int position = 1;

                foreach (var item in dvds)
                {


                    {
                        if (position != int.Parse(item))
                        {
                            operations++;
                        }
                        else
                        {
                            position++;
                        }
                    }
                }
                Console.WriteLine(operations);
                numCases--;
            }
            Console.ReadKey();
            }
        }
    }
