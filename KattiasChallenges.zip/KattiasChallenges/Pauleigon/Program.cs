﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pauleigon
{
    class Program
    {
        static void Main(string[] args)
        {
            //Q-https://open.kattis.com/problems/pauleigon
            string[] data = Console.ReadLine().Split(' ');
            int numserves = int.Parse(data[0]);
            int sumscore = int.Parse(data[1])+ int.Parse(data[2]);
            var result = sumscore / numserves;
            if (result%2==0)
            {
                Console.WriteLine("paul");
            }
            else
            {
                Console.WriteLine("opponent");
            }

            Console.ReadKey();

        }
    }
}
