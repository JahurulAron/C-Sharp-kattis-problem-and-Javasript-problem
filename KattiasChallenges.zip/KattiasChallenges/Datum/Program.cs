﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Datum
{
    class Program
    {
        static void Main(string[] args)
        {
         //   string[] input = Console.ReadLine().Split(' ');
          
         //var format = DateTime.Now.ToString("dd MM yyyy");
            var dateValue = new DateTime(int.Parse(Console.ReadLine()));
            Console.WriteLine(dateValue.ToString("ddd"));
            Console.ReadKey();
        }
    }
}
