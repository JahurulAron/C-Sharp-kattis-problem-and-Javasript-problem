﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrassSeed
{
    class Program
    {
        static void Main(string[] args)
        {
            double unitcost = double.Parse(Console.ReadLine());
            int testcase = int.Parse(Console.ReadLine());
            double result = 0;

            while (testcase>0)
            {
                string[] data = Console.ReadLine().Split(' ');

                double Length = double.Parse(data[0]);
                double Width = double.Parse(data[1]);
                result += unitcost * Length * Width;
               
                testcase--;
            }
            Console.WriteLine(result);

            Console.ReadKey();
        }
    }
}
