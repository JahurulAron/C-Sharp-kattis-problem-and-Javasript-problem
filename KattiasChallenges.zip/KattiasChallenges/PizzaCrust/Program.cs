﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzaCrust
{
    class Program
    {
        static void Main(string[] args)
        {
            //Q-https://open.kattis.com/problems/pizza2
            string[] data = Console.ReadLine().Split(' ');
            double r = double.Parse(data[0]);
            double c = double.Parse(data[1]);
             
            Console.WriteLine((((r - c) * (r - c)) / (r * r)) * 100+".000000000000000000");
            Console.ReadKey();
        }
    }
}
