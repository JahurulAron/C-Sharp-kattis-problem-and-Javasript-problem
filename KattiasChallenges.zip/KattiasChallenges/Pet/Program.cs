﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pet
{
    class Program
    {
        static void Main(string[] args)
        {
            //Q.Problem:-https://open.kattis.com/problems/pet

            int numEvenings = 5;

            int max = 0;
            int winner = 1;
            int contestant = 1;

            while (numEvenings-- > 0)
            {
                string[] grades = Console.ReadLine().Split(' ');
                int sum = 0;

                for (int i = 0; i <grades.Length; i++)
                {
                    sum += int.Parse(grades[i]);
                }
                
                if (sum > max)
                {
                    winner = contestant;
                    max = sum;
                }
                contestant++;
            }

            Console.WriteLine(winner + " " + max);
            Console.ReadKey();
        }
    }
}
