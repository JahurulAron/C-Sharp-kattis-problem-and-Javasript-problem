﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EngineeringEnglish
{
    class Program
    {
        static void Main(string[] args)
        {
            // Set<String> duplicates = new TreeSet<>(String.CASE_INSENSITIVE_ORDER);
            List<string> duplicates = new List<string>();
            string line = Console.ReadLine();

            while (line != null)
            {
                string[] words = line.Split(' ');

                line = "";
                foreach (var word in words)
                {

                    if (duplicates.Contains(word))
                    {
                        line += ". ";
                    }
                    else
                    {
                        duplicates.Add(word);
                        line += word + " ";
                    }
                }
                Console.WriteLine(line);

                line = Console.ReadLine();
            }
            Console.ReadKey();
        }
    }
}