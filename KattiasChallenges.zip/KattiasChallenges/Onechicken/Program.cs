﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Onechicken
{
    class Program
    {
        static void Main(string[] args)
        {
            //Q.-https://open.kattis.com/problems/onechicken
            string[] data = Console.ReadLine().Split(' ');
            int peeple = int.Parse(data[0]);
            int pieces = int.Parse(data[1]);
            int lefrchiken = pieces-peeple;
            if (lefrchiken>0)
            {
                Console.WriteLine($"Dr.Chaz will have {lefrchiken} pieces of chicken left over!");

            }
            else
            {
                Console.WriteLine($"Dr. Chaz needs {Math.Abs(lefrchiken)} more pieces of chicken!");


            }
            Console.ReadKey();
        }
    }
}
