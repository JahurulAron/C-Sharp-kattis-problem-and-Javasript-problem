﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mirror
{
    class Program
    {
        static void Main(string[] args)
        {
            int numCases = int.Parse(Console.ReadLine());

            for (int i = 1; i <= numCases; i++)
            {
                string[] values = Console.ReadLine().Split(' ');
                int numRows = int.Parse(values[0]);

                string[] images = new string[numRows];
                //for (int j = images.Length - 1; j >= 0; j--)
                //{
                //    images[j] = new StringBuilder(Console.ReadLine()).ToString();
                //}
                for (int j = 0; j < images.Length; j++)
                {
                    images[j] = new StringBuilder(Console.ReadLine()).ToString();

                }
                var collection=  images.Reverse();
                Console.WriteLine("Test " + i);
                foreach (var item in collection)
                {
                    Console.WriteLine(item);
                }
            }
            Console.ReadKey();
        }
    }
}