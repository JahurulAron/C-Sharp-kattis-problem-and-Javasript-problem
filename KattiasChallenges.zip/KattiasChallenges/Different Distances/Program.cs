﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Different_Distances
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {


                string[] data = Console.ReadLine().Split(' ');

                double x1 = double.Parse(data[0]);
                if (x1 == 0)
                {
                    break;
                }

                double y1 = double.Parse(data[1]);
                double x2 = double.Parse(data[2]);
                double y2 = double.Parse(data[3]);
                double p = double.Parse(data[4]);

                double pNormDistance = Math.Pow(Math.Pow(Math.Abs(x1 - x2), p) + Math.Pow(Math.Abs(y1 - y2), p), 1 / p);
                Console.WriteLine(pNormDistance);

                Console.ReadKey();

            }
        }
    }
}