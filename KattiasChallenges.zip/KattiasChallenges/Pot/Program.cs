﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pot
{
    class Program
    {
        static void Main(string[] args)
        {
            //q-https://open.kattis.com/problems/pot
            int numAddends = int.Parse(Console.ReadLine());
            long sum = 0;

            while (numAddends-- > 0)
            {
                string number = Console.ReadLine();
                int value = int.Parse(number.Substring(0, number.Length - 1));
                int power = number.Length-1;
                sum += (long)Math.Pow(value, power);
            }
            Console.WriteLine(sum);
            Console.ReadKey();
        }
    }
}
