﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace datumday
{
    class Program
    {
        static void Main(string[] args)
        {
            //string[] input = Console.ReadLine().Split(' ');
            //int[] arr = new int[input.Length];
            ////int sum = 0;
            //for (int i = 0; i < input.Length; i++)
            //{

            //    arr[i]= int.Parse(input[i]);
            //    //sum += arr[i];

            //}
            // Console.WriteLine(sum);
            //DateTime dom = new DateTime(2009,arr[1],arr[0]);
            string[] input = Console.ReadLine().Split(' ');
            int a = int.Parse(input[1]);
            int b = int.Parse(input[0]);
           
           
            DateTime dom = new DateTime(2009, a, b);

            Console.WriteLine(dom.DayOfWeek);
            Console.ReadLine();
        }
    }
}
