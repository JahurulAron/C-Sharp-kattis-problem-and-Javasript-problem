﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modulo
{
    class Program
    {
        static void Main(string[] args)
        {
            //q-https://open.kattis.com/problems/modulo
             int LIFE = 42; // *

          var set = new List <int>();

            for (int i = 0; i < 10; i++)
            {
                int number = int.Parse(Console.ReadLine());

                set.Add(number % LIFE);
            }
            Console.WriteLine (set.Distinct().Count());
            Console.ReadKey();
        }
    }
}
